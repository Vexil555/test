import json
import random
import os

# --- 配置参数 ---
input_jsonl = 'bottle_dataset/metadata.jsonl'
output_dir = 'bottle_dataset'
train_ratio = 0.7
val_ratio = 0.2
# test_ratio will be the rest

# --- 读取所有数据 ---
with open(input_jsonl, 'r', encoding='utf-8') as f:
    all_data = [json.loads(line) for line in f]

# --- 随机打乱数据 ---
random.shuffle(all_data)

# --- 计算切分点 ---
total_size = len(all_data)
train_end = int(total_size * train_ratio)
val_end = int(total_size * (train_ratio + val_ratio))

# --- 切分数据 ---
train_data = all_data[:train_end]
val_data = all_data[train_end:val_end]
test_data = all_data[val_end:]

print(f"数据集划分结果:")
print(f" - 训练集: {len(train_data)} 条")
print(f" - 验证集: {len(val_data)} 条")
print(f" - 测试集: {len(test_data)} 条")

# --- 将切分后的数据写入各自的文件 ---
def write_jsonl(data, filename):
    with open(os.path.join(output_dir, filename), 'w', encoding='utf-8') as f:
        for item in data:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

write_jsonl(train_data, 'train.jsonl')
write_jsonl(val_data, 'validation.jsonl')
write_jsonl(test_data, 'test.jsonl')

print("\n训练集、验证集和测试集已成功生成！")