import json
import requests
import os
from tqdm import tqdm  # 用于显示进度条

# --- 准备工作 ---
# 加载原始数据
with open('pexels_bottle_raw.json', 'r', encoding='utf-8') as f:
    raw_data = json.load(f)

# 创建图片存储目录
output_dir = 'bottle_dataset'
image_dir = os.path.join(output_dir, 'images')
os.makedirs(image_dir, exist_ok=True)

# --- 下载图片并生成metadata.jsonl ---
metadata_file = os.path.join(output_dir, 'metadata.jsonl')

with open(metadata_file, 'w', encoding='utf-8') as f_meta:
    print(f"开始下载图片并生成 {metadata_file}...")
    # 使用tqdm来显示下载进度
    for item in tqdm(raw_data, desc="Downloading images"):
        try:
            image_url = item['image_url']
            # 从URL中获取文件名，并构建本地路径
            image_filename = f"{item['id']}.jpg"
            local_image_path = os.path.join(image_dir, image_filename)

            # 下载图片
            img_data = requests.get(image_url, timeout=10).content
            with open(local_image_path, 'wb') as handler:
                handler.write(img_data)

            # 构建适用于训练的JSON对象
            training_example = {
                'image': os.path.join('images', image_filename),  # 使用相对路径
                'text': item['text']
            }

            # 将JSON对象写入.jsonl文件
            f_meta.write(json.dumps(training_example, ensure_ascii=False) + '\n')

        except Exception as e:
            print(f"处理ID {item['id']} 时出错: {e}")

print("数据集构建完成！")
print(f"图片存放于: {image_dir}")
print(f"元数据文件: {metadata_file}")