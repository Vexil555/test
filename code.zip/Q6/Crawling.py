import requests
import time
import json

# --- 配置参数 ---
API_KEY = 'vpbkttRY1s4y99Gj9pwuRLQFiVAo8h6YuyWpaDxCxKVmziKZ5Q5kt95z'  # 替换为你的API密钥
SEARCH_QUERY = 'bottle'
TARGET_COUNT = 3000
PER_PAGE = 80  # Pexels API每页最多返回80条结果

# --- 初始化变量 ---
headers = {'Authorization': API_KEY}
api_url = 'https://api.pexels.com/v1/search'
params = {'query': SEARCH_QUERY, 'per_page': PER_PAGE, 'page': 1}
image_text_pairs = []
collected_ids = set()  # 用于去重
MAX_RETRIES = 5  # 设置最大重试次数

# --- 开始采集 ---
print("开始从Pexels API采集图文数据...")
while len(image_text_pairs) < TARGET_COUNT:
    retries = 0
    success = False

    # --- 带有重试逻辑的请求 ---
    while retries < MAX_RETRIES and not success:
        try:
            # 设置一个超时，避免永久等待
            response = requests.get(api_url, headers=headers, params=params, timeout=15)
            response.raise_for_status()  # 如果请求失败(如4xx, 5xx错误)则抛出异常
            data = response.json()
            success = True  # 请求成功

        except requests.exceptions.RequestException as e:
            retries += 1
            print(f"请求出错: {e}. 正在进行第 {retries}/{MAX_RETRIES} 次重试...")
            time.sleep(retries * 2)  # 等待时间随重试次数增加

    if not success:
        print("已达到最大重试次数，无法获取数据，脚本终止。")
        break

    # --- 处理成功获取的数据 ---
    if not data.get('photos'):
        print("没有更多数据了，采集结束。")
        break

    for photo in data['photos']:
        photo_id = photo['id']
        if photo_id not in collected_ids:
            image_url = photo['src']['large']
            text_description = photo.get('alt', '').strip()  # 使用.get确保alt键存在

            if text_description:
                image_text_pairs.append({
                    'id': photo_id,
                    'image_url': image_url,
                    'text': text_description
                })
                collected_ids.add(photo_id)

    print(f"当前已采集: {len(image_text_pairs)} / {TARGET_COUNT}")

    if 'next_page' in data:
        params['page'] += 1
        time.sleep(1)  # 礼貌性延迟
    else:
        print("已到达最后一页，采集结束。")
        break

# --- 采集完成后的处理 ---
if image_text_pairs:
    print(f"\n采集完成！总共获得 {len(image_text_pairs)} 条高质量图文对。")
    # 示例输出前几条数据
    for pair in image_text_pairs[:3]:
        print(pair)
    # 保存结果
    with open('pexels_bottle_raw.json', 'w', encoding='utf-8') as f:
        json.dump(image_text_pairs, f, indent=4, ensure_ascii=False)
else:
    print("\n采集失败，未能获取任何数据。请检查API密钥和网络连接。")